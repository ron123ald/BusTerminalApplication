#800-23&10.2971&123.8978&BUS 800-23 has 12 vacancy left with 18 passengers
#800-24&10.2972&123.8979&BUS 800-24 has 12 vacancy left with 18 passengers
#800-25&10.2973&123.8978&BUS 800-25 has 12 vacancy left with 18 passengers

#800-23&10.2974&123.8977&BUS 800-23 has 12 vacancy left with 18 passengers
#800-24&10.2977&123.8976&BUS 800-24 has 12 vacancy left with 18 passengers
#800-25&10.2978&123.8975&BUS 800-25 has 12 vacancy left with 18 passengers

#800-23&10.2975&123.8971&BUS 800-23 has 12 vacancy left with 18 passengers
#800-24&10.2976&123.8972&BUS 800-24 has 12 vacancy left with 18 passengers
#800-25&10.2977&123.8973&BUS 800-25 has 12 vacancy left with 18 passengers