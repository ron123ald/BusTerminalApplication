﻿namespace BusTerminalMonitoringServerApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.busdetails1 = new System.Windows.Forms.TextBox();
            this.vacancy1 = new System.Windows.Forms.TextBox();
            this.occupied1 = new System.Windows.Forms.TextBox();
            this.capacity1 = new System.Windows.Forms.TextBox();
            this.lattitude1 = new System.Windows.Forms.TextBox();
            this.longitude1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.InvokeButton1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.busdetails2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.vacancy2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.occupied2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.InvokeButton2 = new System.Windows.Forms.Button();
            this.capacity2 = new System.Windows.Forms.TextBox();
            this.longitude2 = new System.Windows.Forms.TextBox();
            this.lattitude2 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.busdetails3 = new System.Windows.Forms.TextBox();
            this.vacancy3 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.InvokeButton3 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.occupied3 = new System.Windows.Forms.TextBox();
            this.longitude3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.capacity3 = new System.Windows.Forms.TextBox();
            this.lattitude3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ServerLogBox = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.busdetails1);
            this.panel1.Controls.Add(this.vacancy1);
            this.panel1.Controls.Add(this.occupied1);
            this.panel1.Controls.Add(this.capacity1);
            this.panel1.Controls.Add(this.lattitude1);
            this.panel1.Controls.Add(this.longitude1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.InvokeButton1);
            this.panel1.Location = new System.Drawing.Point(12, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(167, 341);
            this.panel1.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Bus Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Vacancy";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Occupied";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Longitude";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Lattitude";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Capacity";
            // 
            // busdetails1
            // 
            this.busdetails1.Location = new System.Drawing.Point(3, 199);
            this.busdetails1.Multiline = true;
            this.busdetails1.Name = "busdetails1";
            this.busdetails1.Size = new System.Drawing.Size(161, 22);
            this.busdetails1.TabIndex = 6;
            this.busdetails1.Text = "800-23";
            // 
            // vacancy1
            // 
            this.vacancy1.Location = new System.Drawing.Point(101, 149);
            this.vacancy1.Name = "vacancy1";
            this.vacancy1.Size = new System.Drawing.Size(56, 20);
            this.vacancy1.TabIndex = 5;
            this.vacancy1.Text = "18";
            // 
            // occupied1
            // 
            this.occupied1.Location = new System.Drawing.Point(101, 123);
            this.occupied1.Name = "occupied1";
            this.occupied1.Size = new System.Drawing.Size(56, 20);
            this.occupied1.TabIndex = 4;
            this.occupied1.Text = "12";
            // 
            // capacity1
            // 
            this.capacity1.Location = new System.Drawing.Point(101, 97);
            this.capacity1.Name = "capacity1";
            this.capacity1.Size = new System.Drawing.Size(56, 20);
            this.capacity1.TabIndex = 3;
            this.capacity1.Text = "30";
            // 
            // lattitude1
            // 
            this.lattitude1.Location = new System.Drawing.Point(101, 45);
            this.lattitude1.Name = "lattitude1";
            this.lattitude1.Size = new System.Drawing.Size(56, 20);
            this.lattitude1.TabIndex = 1;
            this.lattitude1.Text = "10.29712323";
            // 
            // longitude1
            // 
            this.longitude1.Location = new System.Drawing.Point(101, 71);
            this.longitude1.Name = "longitude1";
            this.longitude1.Size = new System.Drawing.Size(56, 20);
            this.longitude1.TabIndex = 2;
            this.longitude1.Text = "123.897812121";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bus 1";
            // 
            // InvokeButton1
            // 
            this.InvokeButton1.BackColor = System.Drawing.Color.Silver;
            this.InvokeButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InvokeButton1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvokeButton1.Location = new System.Drawing.Point(42, 291);
            this.InvokeButton1.Name = "InvokeButton1";
            this.InvokeButton1.Size = new System.Drawing.Size(76, 31);
            this.InvokeButton1.TabIndex = 7;
            this.InvokeButton1.Text = "Invoke";
            this.InvokeButton1.UseVisualStyleBackColor = false;
            this.InvokeButton1.Click += new System.EventHandler(this.InvokeButton1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.busdetails2);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.vacancy2);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.occupied2);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.InvokeButton2);
            this.panel2.Controls.Add(this.capacity2);
            this.panel2.Controls.Add(this.longitude2);
            this.panel2.Controls.Add(this.lattitude2);
            this.panel2.Location = new System.Drawing.Point(198, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(167, 341);
            this.panel2.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(17, 176);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Bus Number";
            // 
            // busdetails2
            // 
            this.busdetails2.Location = new System.Drawing.Point(3, 199);
            this.busdetails2.Multiline = true;
            this.busdetails2.Name = "busdetails2";
            this.busdetails2.Size = new System.Drawing.Size(161, 22);
            this.busdetails2.TabIndex = 13;
            this.busdetails2.Text = "800-24";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(17, 152);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Vacancy";
            // 
            // vacancy2
            // 
            this.vacancy2.Location = new System.Drawing.Point(101, 149);
            this.vacancy2.Name = "vacancy2";
            this.vacancy2.Size = new System.Drawing.Size(56, 20);
            this.vacancy2.TabIndex = 12;
            this.vacancy2.Text = "11";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(17, 126);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Occupied";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bus 2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 74);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Longitude";
            // 
            // occupied2
            // 
            this.occupied2.Location = new System.Drawing.Point(101, 123);
            this.occupied2.Name = "occupied2";
            this.occupied2.Size = new System.Drawing.Size(56, 20);
            this.occupied2.TabIndex = 11;
            this.occupied2.Text = "19";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Lattitude";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 100);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Capacity";
            // 
            // InvokeButton2
            // 
            this.InvokeButton2.BackColor = System.Drawing.Color.Silver;
            this.InvokeButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InvokeButton2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvokeButton2.Location = new System.Drawing.Point(47, 291);
            this.InvokeButton2.Name = "InvokeButton2";
            this.InvokeButton2.Size = new System.Drawing.Size(76, 31);
            this.InvokeButton2.TabIndex = 14;
            this.InvokeButton2.Text = "Invoke";
            this.InvokeButton2.UseVisualStyleBackColor = false;
            this.InvokeButton2.Click += new System.EventHandler(this.InvokeButton2_Click);
            // 
            // capacity2
            // 
            this.capacity2.Location = new System.Drawing.Point(101, 97);
            this.capacity2.Name = "capacity2";
            this.capacity2.Size = new System.Drawing.Size(56, 20);
            this.capacity2.TabIndex = 10;
            this.capacity2.Text = "30";
            // 
            // longitude2
            // 
            this.longitude2.Location = new System.Drawing.Point(101, 71);
            this.longitude2.Name = "longitude2";
            this.longitude2.Size = new System.Drawing.Size(56, 20);
            this.longitude2.TabIndex = 9;
            this.longitude2.Text = "123.897812121";
            // 
            // lattitude2
            // 
            this.lattitude2.Location = new System.Drawing.Point(101, 45);
            this.lattitude2.Name = "lattitude2";
            this.lattitude2.Size = new System.Drawing.Size(56, 20);
            this.lattitude2.TabIndex = 8;
            this.lattitude2.Text = "10.297124";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.busdetails3);
            this.panel3.Controls.Add(this.vacancy3);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.InvokeButton3);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.occupied3);
            this.panel3.Controls.Add(this.longitude3);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.capacity3);
            this.panel3.Controls.Add(this.lattitude3);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Location = new System.Drawing.Point(392, 31);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(167, 341);
            this.panel3.TabIndex = 0;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(16, 176);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Bus Number";
            // 
            // busdetails3
            // 
            this.busdetails3.Location = new System.Drawing.Point(3, 199);
            this.busdetails3.Multiline = true;
            this.busdetails3.Name = "busdetails3";
            this.busdetails3.Size = new System.Drawing.Size(161, 22);
            this.busdetails3.TabIndex = 20;
            this.busdetails3.Text = "800-25";
            // 
            // vacancy3
            // 
            this.vacancy3.Location = new System.Drawing.Point(101, 149);
            this.vacancy3.Name = "vacancy3";
            this.vacancy3.Size = new System.Drawing.Size(56, 20);
            this.vacancy3.TabIndex = 19;
            this.vacancy3.Text = "7";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 152);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Vacancy";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Bus 3";
            // 
            // InvokeButton3
            // 
            this.InvokeButton3.BackColor = System.Drawing.Color.Silver;
            this.InvokeButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InvokeButton3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvokeButton3.Location = new System.Drawing.Point(43, 291);
            this.InvokeButton3.Name = "InvokeButton3";
            this.InvokeButton3.Size = new System.Drawing.Size(76, 31);
            this.InvokeButton3.TabIndex = 21;
            this.InvokeButton3.Text = "Invoke";
            this.InvokeButton3.UseVisualStyleBackColor = false;
            this.InvokeButton3.Click += new System.EventHandler(this.InvokeButton3_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 126);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "Occupied";
            // 
            // occupied3
            // 
            this.occupied3.Location = new System.Drawing.Point(101, 123);
            this.occupied3.Name = "occupied3";
            this.occupied3.Size = new System.Drawing.Size(56, 20);
            this.occupied3.TabIndex = 18;
            this.occupied3.Text = "23";
            // 
            // longitude3
            // 
            this.longitude3.Location = new System.Drawing.Point(101, 71);
            this.longitude3.Name = "longitude3";
            this.longitude3.Size = new System.Drawing.Size(56, 20);
            this.longitude3.TabIndex = 16;
            this.longitude3.Text = "123.897812121";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(16, 74);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Longitude";
            // 
            // capacity3
            // 
            this.capacity3.Location = new System.Drawing.Point(101, 97);
            this.capacity3.Name = "capacity3";
            this.capacity3.Size = new System.Drawing.Size(56, 20);
            this.capacity3.TabIndex = 17;
            this.capacity3.Text = "30";
            // 
            // lattitude3
            // 
            this.lattitude3.Location = new System.Drawing.Point(101, 45);
            this.lattitude3.Name = "lattitude3";
            this.lattitude3.Size = new System.Drawing.Size(56, 20);
            this.lattitude3.TabIndex = 15;
            this.lattitude3.Text = "10.297125";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(16, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Lattitude";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 100);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "Capacity";
            // 
            // ServerLogBox
            // 
            this.ServerLogBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ServerLogBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ServerLogBox.Location = new System.Drawing.Point(589, 12);
            this.ServerLogBox.Name = "ServerLogBox";
            this.ServerLogBox.Size = new System.Drawing.Size(377, 350);
            this.ServerLogBox.TabIndex = 1;
            this.ServerLogBox.Text = "";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 374);
            this.Controls.Add(this.ServerLogBox);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bus Terminal Monitoring System | Server";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button InvokeButton1;
        private System.Windows.Forms.Button InvokeButton2;
        private System.Windows.Forms.Button InvokeButton3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox vacancy1;
        private System.Windows.Forms.TextBox occupied1;
        private System.Windows.Forms.TextBox capacity1;
        private System.Windows.Forms.TextBox longitude1;
        private System.Windows.Forms.TextBox busdetails1;
        private System.Windows.Forms.TextBox busdetails2;
        private System.Windows.Forms.TextBox vacancy2;
        private System.Windows.Forms.TextBox occupied2;
        private System.Windows.Forms.TextBox capacity2;
        private System.Windows.Forms.TextBox longitude2;
        private System.Windows.Forms.TextBox busdetails3;
        private System.Windows.Forms.TextBox vacancy3;
        private System.Windows.Forms.TextBox occupied3;
        private System.Windows.Forms.TextBox longitude3;
        private System.Windows.Forms.TextBox capacity3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox lattitude1;
        private System.Windows.Forms.TextBox lattitude2;
        private System.Windows.Forms.TextBox lattitude3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox ServerLogBox;
    }
}

