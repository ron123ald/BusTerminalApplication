﻿namespace BusTerminalMonitoringServerApp.Connection
{
    public enum ActionType
    {
        RequestConnection,
        Transmit,
        RequestDisconnection,
        Ping,
        Pong,
        Unknown
    }
}
